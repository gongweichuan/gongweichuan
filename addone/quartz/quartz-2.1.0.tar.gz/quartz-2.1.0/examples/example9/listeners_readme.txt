Example 9
=========

Overview:
=========
This example demonstrates how to use Job Listeners in
Quartz to have the completion of one job trigger another job.


Running the Example:
====================
1. Windows users - Modify the example9.bat file (if necessary) 
to set your JAVA_HOME.  Run example9.bat

2. UNIX/Linux users - Modify the example9.sh file (if necessary)
to set your JAVA_HOME.  Execute example9.sh


Configuration Files:
====================
1.  You can decide to specify a log4j.properties file to
control logging output (optional)
